%% Só para limpar tudo
clear all
clc 
close all

%% Simulink
S = sim("Lab3_P4_AB");

%% Gráficos
figure();
Xfinal=35;
axis([0 Xfinal 0 15])
xline(15,'--', 'Mudança de chão',  "Linewidth", 1.5);
xline(30,'-', 'Parede',  "Linewidth", 1.5);
hold on
% curve=animatedline;
% for ii=1:length(S.z)
% addpoints(curve,S.x(ii),S.z(ii));
% drawnow
% % pause(0.0001)
% end
% hold off
plot(S.x(1:151),S.z(1:151),'b',"linewidth", 1)
plot(S.x(151:301),S.z(151:301),'r', "linewidth", 1)
plot(S.x(301:451),S.z(301:451),'b', "linewidth", 1)
plot(S.x(451:601),S.z(451:601),'r', "linewidth", 1)
title("Posição da bola no espaço com a existência de uma parede")
ylabel("Altura [m]")
xlabel("Distância percorrida [m]")
