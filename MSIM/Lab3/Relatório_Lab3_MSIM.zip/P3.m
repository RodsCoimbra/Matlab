%% Só para limpar tudo
clear all
clc 
close all

%% Simulink
S1 = sim("Lab3_P1_com_horizontal.slx");
S2 = sim("Lab3_P3");

%% Gráficos posição/tempo
% figure();
% Tfinal=20;
% axis([0 Tfinal 0 15])
% plot(S1.t, S1.z)
% hold on
% plot(S2.t,S2.z)
% title("Gráfico da distância da bola ao solo em função do tempo")
% ylabel("Distância relativamente ao solo [m]")
% xlabel("Tempo [s]")

%% Gráficos velocidade
% figure(2)
% plot(S1.t, S1.v)
% hold on
% plot(S2.t,S2.v)
% title("Gráfico da velocidade da bola em função do tempo")
% ylabel("Velocidade da bola [m/s]")
% xlabel("Tempo [s]")

%%Gráficos de posiçao xy
figure(3)
plot(S1.x, S1.z)
hold on
plot(S2.x,S2.z)
title("Posição da bola no espaço")
ylabel("Altura [m]")
xlabel("Distância percorrida [m]")
legend("Sem mudança de chão","Com mudança de chão")






